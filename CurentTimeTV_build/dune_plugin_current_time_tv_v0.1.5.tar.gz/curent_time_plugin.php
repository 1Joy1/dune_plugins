﻿<?php
require_once 'lib/default_dune_plugin_fw.php';
require 'curent_time_tv_plugin.php';

DefaultDunePluginFw::$plugin_class_name = 'CurentTimeTvPlugin';
?>
